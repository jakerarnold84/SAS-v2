# Summit AudienceSegments — Corporate Site (v2)

Static, framework-free site for **summitaudiencesegments.com**. Five pages,
one stylesheet, two image assets. Drop into GitHub Pages and ship.

## What's in this folder

```
index.html       Home (was home.html — renamed so GitHub Pages serves it as root)
platform.html    Platform page (Audience Explorer anchor lives here)
data.html        Data page
thiic.html       THIIC page
about.html       About / contact
styles.css       Single stylesheet · all design tokens
assets/
  logo-icon-pink.png    Brand logomark (used in header + footer + favicon)
  logo-h-white.png      Horizontal lockup (reserved)
.nojekyll        Tells GitHub Pages to skip Jekyll processing
README.md        This file
```

## Deploy to GitHub Pages (5 minutes)

1. Create a new repo on GitHub (public or private).
2. Drag the entire contents of this folder into the **Add file → Upload files**
   screen on the repo's main page. Commit.
3. Go to **Settings → Pages**.
4. Source: **Deploy from a branch**. Branch: `main` (or `master`), folder: `/ (root)`.
5. Save. After ~30 seconds your site is live at `https://<user>.github.io/<repo>/`.
6. Add a custom domain (`summitaudiencesegments.com`) in the same Settings → Pages
   panel if you want it on the apex domain. Add the GitHub Pages records to your DNS:
   - `A` records to 185.199.108.153 · 185.199.109.153 · 185.199.110.153 · 185.199.111.153
   - `CNAME` for `www` → `<user>.github.io`

That's it. No build step. No npm. No framework.

## Editing the site

Every page is a single self-contained HTML file. Open in any editor (VS Code,
Sublime, Notepad++, even Notepad). All styles are in `styles.css` — change a
token at the top of the file and the change propagates everywhere.

### Common edits

- **Change wordmark text** — search for `Summit <b>AudienceSegments</b>` and
  replace in all 5 pages (it appears once in nav, once in footer per page).
- **Change icon** — replace `assets/logo-icon-pink.png` with your new file at
  the same path. Keep the file name the same and every page picks it up.
- **Change accent color** — edit `--c-coral: #EB0557;` in `styles.css`. That
  single token drives every coral element on the site.
- **Edit copy** — open the page's HTML file. Copy is locked verbatim; the
  build team should not paraphrase without sign-off.

## What changed in this revision

- **Header & footer icon** — bumped to 34px with explicit width
  + `flex-shrink:0` so the logomark always renders next to the wordmark in
  both the top nav and the footer brand block.
- **Stat-strip letter-spacing** reduced from `0.16em` to `0.06em` on
  `.stat-strip__cap` so labels like "HCP · Verified Prescribers" fit on
  one line and all 6 cells visually match.
- **Internal nav links** rewritten from `home.html` to `index.html` for
  GitHub Pages compatibility.

## Stack

Plain HTML5 + CSS. No JavaScript framework. No build step. Fonts loaded
from Google Fonts (Inter + JetBrains Mono). Works offline if you mirror
the fonts.
